import { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, Sparkles } from 'lucide-react';
import { Movie } from '../data/movies';

interface AIChatbotProps {
  movies: Movie[];
  favorites: string[];
  watchHistory: string[];
  onMovieClick: (movie: Movie) => void;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  movieSuggestions?: Movie[];
}

export function AIChatbot({ movies, favorites, watchHistory, onMovieClick }: AIChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      content: '👋 Hi! I\'m your MovieMind AI assistant. Ask me for movie recommendations, or just type a movie name!',
    },
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateResponse = (query: string): ChatMessage => {
    const lowerQuery = query.toLowerCase();

    // Check for specific movie name
    const matchedMovie = movies.find((m) => m.title.toLowerCase() === lowerQuery);
    if (matchedMovie) {
      return {
        role: 'assistant',
        content: `Great choice! "${matchedMovie.title}" is a ${matchedMovie.year} ${matchedMovie.genres.join(', ')} film with a ${matchedMovie.rating} rating. Click below to see details!`,
        movieSuggestions: [matchedMovie],
      };
    }

    // Korean thriller request
    if (
      (lowerQuery.includes('korean') && lowerQuery.includes('thriller')) ||
      lowerQuery.includes('k-thriller')
    ) {
      const suggestions = movies.filter(
        (m) => m.language === 'ko' && m.genres.includes('Thriller')
      );
      return {
        role: 'assistant',
        content: '🇰🇷 Here are some incredible Korean thrillers you should watch:',
        movieSuggestions: suggestions,
      };
    }

    // Genre-based recommendations
    if (lowerQuery.includes('action') || lowerQuery.includes('thriller')) {
      const genre = lowerQuery.includes('action') ? 'Action' : 'Thriller';
      const suggestions = movies
        .filter((m) => m.genres.includes(genre) && !watchHistory.includes(m.id))
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
      return {
        role: 'assistant',
        content: `💥 Here are top-rated ${genre} movies you haven't watched yet:`,
        movieSuggestions: suggestions,
      };
    }

    // Horror/scary request
    if (lowerQuery.includes('scary') || lowerQuery.includes('horror')) {
      const suggestions = movies
        .filter((m) => m.genres.includes('Horror') && !watchHistory.includes(m.id))
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
      return {
        role: 'assistant',
        content: '😱 Get ready for some spine-chilling horror films:',
        movieSuggestions: suggestions,
      };
    }

    // Romance request
    if (lowerQuery.includes('romance') || lowerQuery.includes('love')) {
      const suggestions = movies
        .filter((m) => m.genres.includes('Romance') && !watchHistory.includes(m.id))
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
      return {
        role: 'assistant',
        content: '💕 Here are some beautiful romance films for you:',
        movieSuggestions: suggestions,
      };
    }

    // Comedy request
    if (lowerQuery.includes('comedy') || lowerQuery.includes('funny')) {
      const suggestions = movies
        .filter((m) => m.genres.includes('Comedy') && !watchHistory.includes(m.id))
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
      return {
        role: 'assistant',
        content: '😄 Get ready to laugh with these comedy gems:',
        movieSuggestions: suggestions,
      };
    }

    // Based on favorites
    if (
      lowerQuery.includes('based on') ||
      lowerQuery.includes('my favorites') ||
      lowerQuery.includes('recommend')
    ) {
      const favoriteMovies = movies.filter((m) => favorites.includes(m.id));
      const genreCounts: Record<string, number> = {};

      favoriteMovies.forEach((movie) => {
        movie.genres.forEach((genre) => {
          genreCounts[genre] = (genreCounts[genre] || 0) + 1;
        });
      });

      const topGenre = Object.entries(genreCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'Action';

      const suggestions = movies
        .filter((m) => m.genres.includes(topGenre) && !favorites.includes(m.id) && !watchHistory.includes(m.id))
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);

      return {
        role: 'assistant',
        content: `✨ Based on your favorites, I think you'll love these ${topGenre} films:`,
        movieSuggestions: suggestions,
      };
    }

    // Language-based
    if (lowerQuery.includes('hindi') || lowerQuery.includes('bollywood')) {
      const suggestions = movies
        .filter((m) => m.language === 'hi')
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
      return {
        role: 'assistant',
        content: '🇮🇳 Here are some fantastic Bollywood films:',
        movieSuggestions: suggestions,
      };
    }

    if (lowerQuery.includes('japanese') || lowerQuery.includes('anime')) {
      const suggestions = movies
        .filter((m) => m.language === 'ja')
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
      return {
        role: 'assistant',
        content: '🇯🇵 Check out these amazing Japanese films:',
        movieSuggestions: suggestions,
      };
    }

    // Default: trending high-rated
    const suggestions = movies
      .filter((m) => !watchHistory.includes(m.id))
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 5);

    return {
      role: 'assistant',
      content: '🎬 Here are some top-rated movies you might enjoy:',
      movieSuggestions: suggestions,
    };
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = { role: 'user', content: input };
    const aiResponse = generateResponse(input);

    setMessages((prev) => [...prev, userMessage, aiResponse]);
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 size-16 rounded-full bg-gradient-to-br from-red-600 to-red-700 text-white shadow-2xl hover:scale-110 transition-transform z-50 flex items-center justify-center"
      >
        <Bot className="size-7" />
        <Sparkles className="absolute -top-1 -right-1 size-4 text-yellow-300 animate-pulse" />
      </button>

      {/* Chat Panel */}
      {isOpen && (
        <div className="fixed bottom-28 right-8 w-96 h-[32rem] bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl flex flex-col z-50">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="size-8 rounded-full bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center">
                <Bot className="size-5 text-white" />
              </div>
              <div>
                <div className="font-semibold text-white">MovieMind AI</div>
                <div className="text-xs text-zinc-500">Always here to help</div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-zinc-400 hover:text-white transition-colors"
            >
              <X className="size-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, idx) => (
              <div key={idx} className={msg.role === 'user' ? 'flex justify-end' : ''}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2.5 ${
                    msg.role === 'user'
                      ? 'bg-red-600 text-white'
                      : 'bg-zinc-800 text-zinc-100'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{msg.content}</p>
                  {msg.movieSuggestions && msg.movieSuggestions.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {msg.movieSuggestions.map((movie) => (
                        <button
                          key={movie.id}
                          onClick={() => {
                            onMovieClick(movie);
                            setIsOpen(false);
                          }}
                          className="w-full flex items-start gap-3 p-2 rounded-lg bg-zinc-900 hover:bg-zinc-700 transition-colors text-left"
                        >
                          <img
                            src={movie.poster}
                            alt={movie.title}
                            className="w-12 h-16 rounded object-cover"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm text-white truncate">
                              {movie.title}
                            </div>
                            <div className="text-xs text-zinc-400">
                              {movie.year} · ⭐ {movie.rating}
                            </div>
                            <div className="text-xs text-zinc-500 truncate">
                              {movie.genres.join(', ')}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-zinc-800">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask for recommendations..."
                className="flex-1 px-4 py-2.5 bg-zinc-800 text-white rounded-xl border border-zinc-700 focus:outline-none focus:border-red-600 transition-colors placeholder:text-zinc-500"
              />
              <button
                onClick={handleSend}
                className="px-4 py-2.5 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
              >
                <Send className="size-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
