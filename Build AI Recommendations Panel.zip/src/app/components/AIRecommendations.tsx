import { Sparkles, TrendingUp, Clock, Brain } from 'lucide-react';
import { Movie } from '../data/movies';

interface AIRecommendationsProps {
  topGenre: string;
  recommendations: Movie[];
  trending: Movie[];
  aiLearnedMovies: Array<{ id: string; title: string; timestamp: number }>;
  watchedCount: number;
  onMovieClick: (movie: Movie) => void;
}

export function AIRecommendations({
  topGenre,
  recommendations,
  trending,
  aiLearnedMovies,
  watchedCount,
  onMovieClick,
}: AIRecommendationsProps) {
  return (
    <div className="w-80 bg-zinc-900/50 border-l border-zinc-800 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="size-5 text-red-500" />
          <h2 className="font-semibold text-white">AI Recommendations</h2>
        </div>
        <p className="text-sm text-zinc-400">Personalized picks just for you</p>
      </div>

      {/* Based on Your Taste */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <Brain className="size-4 text-red-400" />
          <h3 className="text-sm font-medium text-zinc-300">
            Because you love {topGenre}
          </h3>
        </div>
        <div className="space-y-2">
          {recommendations.length > 0 ? (
            recommendations.map((movie) => (
              <button
                key={movie.id}
                onClick={() => onMovieClick(movie)}
                className="w-full flex items-start gap-3 p-2 rounded-lg bg-zinc-800/50 hover:bg-zinc-700 transition-colors text-left"
              >
                <img
                  src={movie.poster}
                  alt={movie.title}
                  className="w-12 h-16 rounded object-cover"
                />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm text-white truncate">
                    {movie.title}
                  </div>
                  <div className="text-xs text-zinc-400">{movie.year}</div>
                  <div className="text-xs text-red-400">⭐ {movie.rating}</div>
                </div>
              </button>
            ))
          ) : (
            <p className="text-xs text-zinc-500 italic">
              Add some favorites to get personalized recommendations!
            </p>
          )}
        </div>
      </div>

      {/* AI Just Learned */}
      {aiLearnedMovies.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <Brain className="size-4 text-purple-400" />
            <h3 className="text-sm font-medium text-zinc-300">AI Just Learned</h3>
          </div>
          <div className="space-y-2">
            {aiLearnedMovies.slice(-5).reverse().map((learned) => (
              <div
                key={learned.id}
                className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/20"
              >
                <div className="text-sm text-white font-medium">{learned.title}</div>
                <div className="text-xs text-purple-300 mt-1">
                  Learned from your search · Will appear next time
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Trending Now */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="size-4 text-yellow-400" />
          <h3 className="text-sm font-medium text-zinc-300">Trending Now</h3>
        </div>
        <div className="space-y-2">
          {trending.map((movie) => (
            <button
              key={movie.id}
              onClick={() => onMovieClick(movie)}
              className="w-full flex items-start gap-3 p-2 rounded-lg bg-zinc-800/50 hover:bg-zinc-700 transition-colors text-left"
            >
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-12 h-16 rounded object-cover"
              />
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm text-white truncate">
                  {movie.title}
                </div>
                <div className="text-xs text-zinc-400">{movie.year}</div>
                <div className="text-xs text-yellow-400">⭐ {movie.rating}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Your Stats */}
      <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="size-4 text-green-400" />
          <h3 className="text-sm font-medium text-zinc-300">Your Stats</h3>
        </div>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-zinc-400">Movies Watched</span>
            <span className="text-white font-semibold">{watchedCount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-400">Favorite Genre</span>
            <span className="text-white font-semibold">{topGenre}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zinc-400">AI Learned</span>
            <span className="text-purple-400 font-semibold">{aiLearnedMovies.length}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
