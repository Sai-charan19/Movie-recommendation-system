import { Heart, Eye, Star } from 'lucide-react';
import { Movie, LANGUAGES } from '../data/movies';

interface MovieCardProps {
  movie: Movie;
  isFavorite: boolean;
  isWatched: boolean;
  onToggleFavorite: (id: string) => void;
  onToggleWatched: (id: string) => void;
  onClick: (movie: Movie) => void;
  compact?: boolean;
}

export function MovieCard({
  movie,
  isFavorite,
  isWatched,
  onToggleFavorite,
  onToggleWatched,
  onClick,
  compact = false,
}: MovieCardProps) {
  const languageName = LANGUAGES.find((l) => l.code === movie.language)?.name || movie.language;

  const fallbackPoster = `https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&q=80&fit=crop`;

  return (
    <div
      className="group relative bg-zinc-900 rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform duration-300 hover:z-10 hover:shadow-2xl hover:shadow-black/50"
      onClick={() => onClick(movie)}
    >
      {/* Poster */}
      <div className="aspect-[2/3] overflow-hidden bg-zinc-800">
        <img
          src={movie.poster || fallbackPoster}
          alt={movie.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src = fallbackPoster;
          }}
        />
      </div>

      {/* Hover overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
        <p className="text-xs text-zinc-300 line-clamp-3 mb-2">{movie.overview}</p>
        {movie.director && (
          <p className="text-xs text-zinc-500 truncate">Dir: {movie.director}</p>
        )}
      </div>

      {/* AI Generated Badge */}
      {movie.isAIGenerated && (
        <div className="absolute top-2 left-2 px-2 py-0.5 bg-purple-600 text-white text-xs font-semibold rounded">
          AI ✨
        </div>
      )}

      {/* Action Buttons */}
      <div className="absolute top-2 right-2 flex gap-1">
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFavorite(movie.id); }}
          className={`size-7 rounded-full backdrop-blur-md flex items-center justify-center transition-all ${
            isFavorite ? 'bg-red-600 text-white scale-110' : 'bg-black/50 text-white hover:bg-red-600'
          }`}
        >
          <Heart className={`size-3.5 ${isFavorite ? 'fill-current' : ''}`} />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); onToggleWatched(movie.id); }}
          className={`size-7 rounded-full backdrop-blur-md flex items-center justify-center transition-all ${
            isWatched ? 'bg-green-600 text-white scale-110' : 'bg-black/50 text-white hover:bg-green-600'
          }`}
        >
          <Eye className={`size-3.5 ${isWatched ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Info footer */}
      {!compact && (
        <div className="p-3">
          <h3 className="font-semibold text-white mb-1 truncate text-sm">{movie.title}</h3>
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
            <span>{movie.year}</span>
            <span>{languageName}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 text-yellow-500">
              <Star className="size-3.5 fill-current" />
              <span className="font-semibold text-xs">{movie.rating}</span>
            </div>
            <div className="flex gap-1">
              {movie.genres.slice(0, 1).map((genre) => (
                <span key={genre} className="px-1.5 py-0.5 bg-zinc-800 text-zinc-300 text-xs rounded">
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Compact mode: title at bottom on hover */}
      {compact && (
        <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/90 to-transparent translate-y-full group-hover:translate-y-0 transition-transform">
          <h3 className="text-xs font-semibold text-white truncate">{movie.title}</h3>
          <div className="flex items-center gap-2 text-zinc-400 text-xs mt-0.5">
            <span>{movie.year}</span>
            <div className="flex items-center gap-0.5 text-yellow-500">
              <Star className="size-3 fill-current" />
              <span>{movie.rating}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
