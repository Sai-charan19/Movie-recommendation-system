import { X, Star, Heart, Eye, Calendar, Globe, Clock, Play, Users, Film } from 'lucide-react';
import { Movie, LANGUAGES } from '../data/movies';

interface MovieModalProps {
  movie: Movie;
  isFavorite: boolean;
  isWatched: boolean;
  onClose: () => void;
  onToggleFavorite: (id: string) => void;
  onToggleWatched: (id: string) => void;
}

export function MovieModal({
  movie,
  isFavorite,
  isWatched,
  onClose,
  onToggleFavorite,
  onToggleWatched,
}: MovieModalProps) {
  const languageInfo = LANGUAGES.find((l) => l.code === movie.language);
  const fallback = `https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=1200&q=80&fit=crop`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-zinc-900 rounded-2xl overflow-hidden max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Backdrop */}
        <div className="relative h-72 md:h-96 flex-none">
          <img
            src={movie.backdrop || movie.poster || fallback}
            alt={movie.title}
            className="w-full h-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).src = fallback; }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/60 to-transparent" />

          <button
            onClick={onClose}
            className="absolute top-4 right-4 size-10 rounded-full bg-black/50 backdrop-blur-md text-white hover:bg-black/70 transition-colors flex items-center justify-center"
          >
            <X className="size-6" />
          </button>

          {/* Poster + Title */}
          <div className="absolute bottom-0 left-0 right-0 p-6 flex gap-5 items-end">
            <img
              src={movie.poster || fallback}
              alt={movie.title}
              className="w-28 md:w-40 rounded-lg shadow-2xl object-cover flex-none hidden sm:block"
              style={{ aspectRatio: '2/3' }}
              onError={(e) => { (e.target as HTMLImageElement).src = fallback; }}
            />
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl md:text-4xl font-black text-white mb-2 leading-tight">{movie.title}</h1>
              {movie.originalTitle && movie.originalTitle !== movie.title && (
                <p className="text-zinc-400 text-sm mb-2 italic">{movie.originalTitle}</p>
              )}
              <div className="flex flex-wrap items-center gap-3 text-zinc-300 text-sm mb-3">
                <div className="flex items-center gap-1">
                  <Calendar className="size-4" />
                  <span>{movie.year}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Globe className="size-4" />
                  <span>{languageInfo?.flag} {languageInfo?.name}</span>
                </div>
                {movie.runtime && (
                  <div className="flex items-center gap-1">
                    <Clock className="size-4" />
                    <span>{Math.floor(movie.runtime / 60)}h {movie.runtime % 60}m</span>
                  </div>
                )}
                <div className="flex items-center gap-1 text-yellow-400">
                  <Star className="size-5 fill-current" />
                  <span className="text-xl font-bold">{movie.rating.toFixed(1)}</span>
                  {movie.voteCount && (
                    <span className="text-xs text-zinc-500">({(movie.voteCount / 1000).toFixed(0)}K votes)</span>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {movie.genres.map((g) => (
                  <span key={g} className="px-3 py-1 bg-zinc-800/80 text-zinc-200 text-xs rounded-full border border-zinc-700/50">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8 space-y-6">
          {/* Action Buttons */}
          <div className="flex gap-3 flex-wrap">
            {movie.trailer && (
              <a
                href={movie.trailer}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition-colors"
              >
                <Play className="size-4 fill-current" />
                Watch Trailer
              </a>
            )}
            <button
              onClick={() => onToggleFavorite(movie.id)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold transition-all ${
                isFavorite ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-zinc-800 text-white hover:bg-zinc-700'
              }`}
            >
              <Heart className={`size-4 ${isFavorite ? 'fill-current' : ''}`} />
              {isFavorite ? 'Favorited' : 'Add to Favorites'}
            </button>
            <button
              onClick={() => onToggleWatched(movie.id)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold transition-all ${
                isWatched ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-zinc-800 text-white hover:bg-zinc-700'
              }`}
            >
              <Eye className={`size-4 ${isWatched ? 'fill-current' : ''}`} />
              {isWatched ? 'Watched ✓' : 'Mark as Watched'}
            </button>
          </div>

          {/* Overview */}
          <div>
            <h2 className="text-lg font-semibold text-white mb-2">Overview</h2>
            <p className="text-zinc-300 leading-relaxed">{movie.overview}</p>
          </div>

          {/* Director + Cast */}
          {(movie.director || (movie.cast && movie.cast.length > 0)) && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {movie.director && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Film className="size-4 text-red-400" />
                    <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">Director</h3>
                  </div>
                  <p className="text-white font-medium">{movie.director}</p>
                </div>
              )}
              {movie.cast && movie.cast.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="size-4 text-red-400" />
                    <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider">Cast</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {movie.cast.slice(0, 5).map((actor) => (
                      <span key={actor} className="px-3 py-1 bg-zinc-800 text-zinc-300 text-sm rounded-full">
                        {actor}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* AI Generated Notice */}
          {movie.isAIGenerated && (
            <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-xl">
              <div className="flex items-center gap-2 text-purple-300 mb-1">
                <span className="text-lg">✨</span>
                <span className="font-semibold">AI Generated Entry</span>
              </div>
              <p className="text-sm text-purple-200">
                This movie was added based on your search. Details have been inferred by AI.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
