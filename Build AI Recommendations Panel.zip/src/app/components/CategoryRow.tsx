import { useRef } from 'react';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { Movie } from '../data/movies';
import { MovieCard } from './MovieCard';

interface CategoryRowProps {
  title: string;
  movies: Movie[];
  loading?: boolean;
  favorites: string[];
  watchHistory: string[];
  onToggleFavorite: (id: string) => void;
  onToggleWatched: (id: string) => void;
  onMovieClick: (movie: Movie) => void;
}

export function CategoryRow({
  title,
  movies,
  loading = false,
  favorites,
  watchHistory,
  onToggleFavorite,
  onToggleWatched,
  onMovieClick,
}: CategoryRowProps) {
  const rowRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (!rowRef.current) return;
    const amount = rowRef.current.clientWidth * 0.75;
    rowRef.current.scrollBy({ left: dir === 'left' ? -amount : amount, behavior: 'smooth' });
  };

  if (!loading && movies.length === 0) return null;

  return (
    <div className="mb-8 group/row">
      <h2 className="text-xl font-semibold text-white mb-3 px-6">{title}</h2>

      <div className="relative">
        {/* Left Arrow */}
        <button
          onClick={() => scroll('left')}
          className="absolute left-2 top-1/2 -translate-y-1/2 z-20 size-10 rounded-full bg-black/70 border border-zinc-700 text-white flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity hover:bg-black/90 hover:scale-110"
        >
          <ChevronLeft className="size-5" />
        </button>

        {/* Movie Row */}
        <div
          ref={rowRef}
          className="flex gap-3 overflow-x-auto scrollbar-hide px-6 pb-2"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {loading
            ? Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="flex-none w-40 aspect-[2/3] bg-zinc-800 rounded-lg animate-pulse"
                />
              ))
            : movies.slice(0, 20).map((movie) => (
                <div key={movie.id} className="flex-none w-40">
                  <MovieCard
                    movie={movie}
                    isFavorite={favorites.includes(movie.id)}
                    isWatched={watchHistory.includes(movie.id)}
                    onToggleFavorite={onToggleFavorite}
                    onToggleWatched={onToggleWatched}
                    onClick={onMovieClick}
                    compact
                  />
                </div>
              ))}
        </div>

        {/* Right Arrow */}
        <button
          onClick={() => scroll('right')}
          className="absolute right-2 top-1/2 -translate-y-1/2 z-20 size-10 rounded-full bg-black/70 border border-zinc-700 text-white flex items-center justify-center opacity-0 group-hover/row:opacity-100 transition-opacity hover:bg-black/90 hover:scale-110"
        >
          <ChevronRight className="size-5" />
        </button>
      </div>
    </div>
  );
}

export function LoadingRow({ title }: { title: string }) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-2 mb-3 px-6">
        <h2 className="text-xl font-semibold text-white">{title}</h2>
        <Loader2 className="size-4 text-red-400 animate-spin" />
      </div>
      <div className="flex gap-3 px-6">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="flex-none w-40 aspect-[2/3] bg-zinc-800 rounded-lg animate-pulse" />
        ))}
      </div>
    </div>
  );
}
