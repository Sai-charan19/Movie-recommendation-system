import { useState, useEffect } from 'react';
import { Play, Info, Star, Clock, Globe, Heart, Eye } from 'lucide-react';
import { Movie, LANGUAGES } from '../data/movies';

interface HeroBannerProps {
  movies: Movie[];
  onMovieClick: (movie: Movie) => void;
  onToggleFavorite: (id: string) => void;
  onToggleWatched: (id: string) => void;
  favorites: string[];
  watchHistory: string[];
}

export function HeroBanner({
  movies,
  onMovieClick,
  onToggleFavorite,
  onToggleWatched,
  favorites,
  watchHistory,
}: HeroBannerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-rotate hero every 8 seconds
  useEffect(() => {
    if (movies.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % Math.min(movies.length, 8));
    }, 8000);
    return () => clearInterval(timer);
  }, [movies.length]);

  if (movies.length === 0) return null;

  const movie = movies[currentIndex];
  const lang = LANGUAGES.find((l) => l.code === movie.language);
  const isFav = favorites.includes(movie.id);
  const isWatched = watchHistory.includes(movie.id);

  return (
    <div className="relative h-[70vh] min-h-[500px] overflow-hidden">
      {/* Backdrop image with crossfade */}
      {movies.slice(0, 8).map((m, i) => (
        <div
          key={m.id}
          className="absolute inset-0 transition-opacity duration-1000"
          style={{ opacity: i === currentIndex ? 1 : 0 }}
        >
          <img
            src={m.backdrop || m.poster}
            alt={m.title}
            className="w-full h-full object-cover"
          />
        </div>
      ))}

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-black/20" />

      {/* Content */}
      <div className="absolute inset-0 flex items-center px-6 md:px-12">
        <div className="max-w-xl">
          {/* Language badge */}
          {lang && (
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{lang.flag}</span>
              <span className="px-3 py-1 bg-red-600/80 text-white text-sm font-semibold rounded-full backdrop-blur-sm">
                {lang.name}
              </span>
            </div>
          )}

          <h1 className="text-4xl md:text-6xl font-black text-white mb-3 leading-tight drop-shadow-2xl">
            {movie.title}
          </h1>

          {/* Meta */}
          <div className="flex items-center gap-4 mb-4 text-sm text-zinc-300">
            <div className="flex items-center gap-1 text-yellow-400">
              <Star className="size-4 fill-current" />
              <span className="font-bold">{movie.rating.toFixed(1)}</span>
            </div>
            <span>{movie.year}</span>
            {movie.runtime && (
              <div className="flex items-center gap-1">
                <Clock className="size-3" />
                <span>{Math.floor(movie.runtime / 60)}h {movie.runtime % 60}m</span>
              </div>
            )}
          </div>

          {/* Genres */}
          <div className="flex flex-wrap gap-2 mb-4">
            {movie.genres.slice(0, 3).map((g) => (
              <span key={g} className="px-3 py-1 bg-zinc-800/70 text-zinc-200 text-xs rounded-full border border-zinc-700/50 backdrop-blur-sm">
                {g}
              </span>
            ))}
          </div>

          <p className="text-zinc-300 text-sm leading-relaxed mb-6 line-clamp-3 max-w-md">
            {movie.overview}
          </p>

          {/* Buttons */}
          <div className="flex gap-3 flex-wrap">
            {movie.trailer ? (
              <a
                href={movie.trailer}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition-all hover:scale-105 shadow-lg"
              >
                <Play className="size-5 fill-current" />
                Watch Trailer
              </a>
            ) : null}
            <button
              onClick={() => onMovieClick(movie)}
              className="flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl backdrop-blur-sm border border-white/20 transition-all hover:scale-105"
            >
              <Info className="size-5" />
              More Info
            </button>
            <button
              onClick={() => onToggleFavorite(movie.id)}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all hover:scale-105 ${
                isFav
                  ? 'bg-red-600/80 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/20'
              }`}
            >
              <Heart className={`size-5 ${isFav ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={() => onToggleWatched(movie.id)}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all hover:scale-105 ${
                isWatched
                  ? 'bg-green-600/80 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm border border-white/20'
              }`}
            >
              <Eye className={`size-5 ${isWatched ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Dot indicators */}
      <div className="absolute bottom-8 right-8 flex gap-2">
        {movies.slice(0, 8).map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`transition-all rounded-full ${
              i === currentIndex
                ? 'w-6 h-2 bg-red-500'
                : 'w-2 h-2 bg-white/40 hover:bg-white/70'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
