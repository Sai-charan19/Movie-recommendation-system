import { useState } from 'react';
import { Key, ExternalLink, Check, Loader2, X, AlertCircle } from 'lucide-react';

interface TMDbSetupProps {
  onSave: (key: string) => Promise<boolean>;
  onDismiss?: () => void;
  isValidating: boolean;
  validationError: string | null;
  compact?: boolean;
}

export function TMDbSetup({ onSave, onDismiss, isValidating, validationError, compact }: TMDbSetupProps) {
  const [key, setKey] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!key.trim()) return;
    const ok = await onSave(key.trim());
    if (ok) setSuccess(true);
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2 px-4 py-2 bg-zinc-800/80 border border-zinc-700 rounded-lg">
        <Key className="size-4 text-yellow-400 flex-none" />
        <span className="text-sm text-zinc-400">Add TMDb API key for real movie data</span>
        <form onSubmit={handleSubmit} className="flex gap-2 ml-2">
          <input
            type="text"
            placeholder="Paste API key..."
            value={key}
            onChange={(e) => setKey(e.target.value)}
            className="px-3 py-1 bg-zinc-900 border border-zinc-600 rounded text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-red-500 w-48"
          />
          <button
            type="submit"
            disabled={isValidating || !key.trim()}
            className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white text-sm rounded transition-colors disabled:opacity-50 flex items-center gap-1"
          >
            {isValidating ? <Loader2 className="size-3 animate-spin" /> : <Check className="size-3" />}
            {isValidating ? 'Checking...' : 'Connect'}
          </button>
        </form>
        {onDismiss && (
          <button onClick={onDismiss} className="text-zinc-500 hover:text-white">
            <X className="size-4" />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto bg-zinc-900 rounded-2xl border border-zinc-800 p-8">
      <div className="text-center mb-6">
        <div className="size-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
          <Key className="size-8 text-yellow-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Connect TMDb API</h2>
        <p className="text-zinc-400 text-sm">
          Unlock 500,000+ movies with real posters, details, and live data from The Movie Database.
        </p>
      </div>

      <div className="space-y-4 mb-6 text-sm text-zinc-300">
        <div className="flex items-start gap-3 p-3 bg-zinc-800/50 rounded-lg">
          <span className="size-6 rounded-full bg-red-600 text-white flex items-center justify-center text-xs font-bold flex-none">1</span>
          <div>
            <p>Go to{' '}
              <a
                href="https://www.themoviedb.org/settings/api"
                target="_blank"
                rel="noopener noreferrer"
                className="text-red-400 hover:text-red-300 underline inline-flex items-center gap-1"
              >
                TMDb API Settings <ExternalLink className="size-3" />
              </a>
            </p>
            <p className="text-zinc-500 text-xs mt-1">Create a free account if you don't have one.</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-3 bg-zinc-800/50 rounded-lg">
          <span className="size-6 rounded-full bg-red-600 text-white flex items-center justify-center text-xs font-bold flex-none">2</span>
          <p>Request an API key (v3 auth) — it's free and approved instantly.</p>
        </div>
        <div className="flex items-start gap-3 p-3 bg-zinc-800/50 rounded-lg">
          <span className="size-6 rounded-full bg-red-600 text-white flex items-center justify-center text-xs font-bold flex-none">3</span>
          <p>Paste your API key below and click Connect.</p>
        </div>
      </div>

      {success ? (
        <div className="flex items-center gap-3 p-4 bg-green-500/10 border border-green-500/20 rounded-xl text-green-400">
          <Check className="size-5" />
          <span>API key connected successfully! Loading movies...</span>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="text"
            placeholder="Paste your TMDb API key (v3)"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-xl text-white placeholder:text-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
          />
          {validationError && (
            <div className="flex items-center gap-2 text-red-400 text-sm">
              <AlertCircle className="size-4" />
              <span>{validationError}</span>
            </div>
          )}
          <button
            type="submit"
            disabled={isValidating || !key.trim()}
            className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isValidating ? (
              <><Loader2 className="size-5 animate-spin" /> Validating...</>
            ) : (
              <><Check className="size-5" /> Connect TMDb</>
            )}
          </button>
        </form>
      )}

      {onDismiss && (
        <button
          onClick={onDismiss}
          className="w-full mt-3 py-2 text-zinc-500 hover:text-zinc-300 text-sm transition-colors"
        >
          Continue with local database only
        </button>
      )}
    </div>
  );
}
