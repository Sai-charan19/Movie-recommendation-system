import { Movie } from '../data/movies';

const TMDB_BASE = 'https://api.themoviedb.org/3';
const TMDB_IMG = 'https://image.tmdb.org/t/p/w500';
const TMDB_BACKDROP = 'https://image.tmdb.org/t/p/original';

export const TMDB_GENRE_MAP: Record<number, string> = {
  28: 'Action',
  12: 'Adventure',
  16: 'Animation',
  35: 'Comedy',
  80: 'Crime',
  18: 'Drama',
  14: 'Fantasy',
  36: 'Biography',
  27: 'Horror',
  9648: 'Mystery',
  10749: 'Romance',
  878: 'Sci-Fi',
  53: 'Thriller',
  10752: 'War',
  37: 'Western',
};

export const TMDB_LANGUAGE_MAP: Record<string, string> = {
  en: 'en-US',
  hi: 'hi-IN',
  ta: 'ta-IN',
  te: 'te-IN',
  ml: 'ml-IN',
  kn: 'kn-IN',
  ko: 'ko-KR',
  ja: 'ja-JP',
  es: 'es-ES',
  fr: 'fr-FR',
  pt: 'pt-BR',
  zh: 'zh-CN',
  de: 'de-DE',
  it: 'it-IT',
  ru: 'ru-RU',
};

export interface TMDbMovie {
  id: number;
  title: string;
  original_title: string;
  original_language: string;
  release_date: string;
  vote_average: number;
  vote_count: number;
  genre_ids: number[];
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
}

export interface TMDbMovieDetail extends TMDbMovie {
  runtime: number;
  credits?: {
    cast: Array<{ name: string; order: number }>;
    crew: Array<{ name: string; job: string }>;
  };
  videos?: {
    results: Array<{ key: string; site: string; type: string }>;
  };
}

function tmdbMovieToMovie(m: TMDbMovie): Movie {
  const year = m.release_date ? parseInt(m.release_date.slice(0, 4)) : 0;
  const genres = (m.genre_ids || [])
    .map((id) => TMDB_GENRE_MAP[id])
    .filter(Boolean) as string[];

  return {
    id: `tmdb-${m.id}`,
    tmdbId: m.id,
    title: m.title,
    originalTitle: m.original_title !== m.title ? m.original_title : undefined,
    language: m.original_language,
    year,
    rating: Math.round(m.vote_average * 10) / 10,
    voteCount: m.vote_count,
    genres: genres.length > 0 ? genres : ['Drama'],
    overview: m.overview || 'No overview available.',
    poster: m.poster_path ? `${TMDB_IMG}${m.poster_path}` : '',
    backdrop: m.backdrop_path ? `${TMDB_BACKDROP}${m.backdrop_path}` : undefined,
  };
}

function tmdbDetailToMovie(m: TMDbMovieDetail): Movie {
  const base = tmdbMovieToMovie(m);
  const director = m.credits?.crew?.find((c) => c.job === 'Director')?.name;
  const cast = m.credits?.cast?.slice(0, 5).map((c) => c.name);
  const trailerKey = m.videos?.results?.find(
    (v) => v.site === 'YouTube' && v.type === 'Trailer'
  )?.key;

  return {
    ...base,
    runtime: m.runtime,
    director,
    cast,
    trailer: trailerKey ? `https://www.youtube.com/watch?v=${trailerKey}` : undefined,
  };
}

export class TMDbService {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private url(path: string, params: Record<string, string | number> = {}): string {
    const p = new URLSearchParams({ api_key: this.apiKey, ...params as Record<string, string> });
    return `${TMDB_BASE}${path}?${p}`;
  }

  private async fetchJSON<T>(path: string, params: Record<string, string | number> = {}): Promise<T> {
    const res = await fetch(this.url(path, params));
    if (!res.ok) throw new Error(`TMDb API error: ${res.status}`);
    return res.json();
  }

  async validateKey(): Promise<boolean> {
    try {
      await this.fetchJSON('/configuration');
      return true;
    } catch {
      return false;
    }
  }

  async fetchTrending(timeWindow: 'day' | 'week' = 'week', page = 1): Promise<Movie[]> {
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>(`/trending/movie/${timeWindow}`, { page });
    return data.results.map(tmdbMovieToMovie);
  }

  async fetchPopular(language?: string, page = 1): Promise<Movie[]> {
    const params: Record<string, string | number> = { page };
    if (language) params.with_original_language = language;
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>('/discover/movie', {
      ...params,
      sort_by: 'popularity.desc',
    });
    return data.results.map(tmdbMovieToMovie);
  }

  async fetchTopRated(page = 1): Promise<Movie[]> {
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>('/movie/top_rated', { page });
    return data.results.map(tmdbMovieToMovie);
  }

  async fetchNowPlaying(page = 1): Promise<Movie[]> {
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>('/movie/now_playing', { page });
    return data.results.map(tmdbMovieToMovie);
  }

  async fetchByLanguage(langCode: string, page = 1): Promise<Movie[]> {
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>('/discover/movie', {
      with_original_language: langCode,
      sort_by: 'popularity.desc',
      page,
      'vote_count.gte': 100,
    });
    return data.results.map(tmdbMovieToMovie);
  }

  async fetchByGenre(tmdbGenreId: number, langCode?: string, page = 1): Promise<Movie[]> {
    const params: Record<string, string | number> = {
      with_genres: tmdbGenreId,
      sort_by: 'popularity.desc',
      page,
      'vote_count.gte': 200,
    };
    if (langCode) params.with_original_language = langCode;
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>('/discover/movie', params);
    return data.results.map(tmdbMovieToMovie);
  }

  async searchMovies(query: string, langCode?: string): Promise<Movie[]> {
    const params: Record<string, string | number> = { query };
    if (langCode && langCode !== 'all') params.language = TMDB_LANGUAGE_MAP[langCode] || 'en-US';
    const data = await this.fetchJSON<{ results: TMDbMovie[] }>('/search/movie', params);
    return data.results.map(tmdbMovieToMovie);
  }

  async fetchMovieDetails(tmdbId: number): Promise<Movie> {
    const data = await this.fetchJSON<TMDbMovieDetail>(`/movie/${tmdbId}`, {
      append_to_response: 'credits,videos',
    });
    return tmdbDetailToMovie(data);
  }

  async enrichMovie(movie: Movie): Promise<Movie> {
    if (!movie.tmdbId) return movie;
    try {
      const detail = await this.fetchMovieDetails(movie.tmdbId);
      return {
        ...movie,
        cast: detail.cast || movie.cast,
        director: detail.director || movie.director,
        runtime: detail.runtime || movie.runtime,
        trailer: detail.trailer || movie.trailer,
        poster: detail.poster || movie.poster,
        backdrop: detail.backdrop || movie.backdrop,
      };
    } catch {
      return movie;
    }
  }
}

// Singleton – recreated when key changes
let _service: TMDbService | null = null;

export function getTMDbService(): TMDbService | null {
  const key = localStorage.getItem('moviemind-tmdb-key');
  if (!key) return null;
  if (!_service) _service = new TMDbService(key);
  return _service;
}

export function setTMDbKey(key: string): TMDbService {
  localStorage.setItem('moviemind-tmdb-key', key);
  _service = new TMDbService(key);
  return _service;
}

export function clearTMDbKey() {
  localStorage.removeItem('moviemind-tmdb-key');
  _service = null;
}

export function getTMDbKey(): string {
  return localStorage.getItem('moviemind-tmdb-key') || '';
}
