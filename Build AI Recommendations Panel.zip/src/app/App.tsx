import { useState, useEffect, useMemo, useCallback } from 'react';
import { Search, Film, Heart, Eye, ChevronDown, LayoutGrid, Home, X, Settings, Tv2 } from 'lucide-react';
import { initialMovies, Movie, LANGUAGES, GENRES } from './data/movies';
import { useMovieAI } from './hooks/useMovieAI';
import { useTMDb } from './hooks/useTMDb';
import { MovieCard } from './components/MovieCard';
import { MovieModal } from './components/MovieModal';
import { AIChatbot } from './components/AIChatbot';
import { AIRecommendations } from './components/AIRecommendations';
import { CategoryRow } from './components/CategoryRow';
import { HeroBanner } from './components/HeroBanner';
import { TMDbSetup } from './components/TMDbSetup';

type TabType = 'all' | 'favorites' | 'watched';
type SortType = 'rating' | 'newest' | 'alphabetical';
type ViewMode = 'home' | 'browse';

// Group static movies into per-language rows
function groupByLanguage(movies: Movie[]): Map<string, Movie[]> {
  const map = new Map<string, Movie[]>();
  for (const m of movies) {
    if (!map.has(m.language)) map.set(m.language, []);
    map.get(m.language)!.push(m);
  }
  return map;
}

// Language display priority
const LANG_PRIORITY = ['en', 'hi', 'te', 'ta', 'ml', 'kn', 'ko', 'ja', 'zh', 'es', 'fr', 'pt', 'de', 'it', 'ru'];

export default function App() {
  const [movies, setMovies] = useState<Movie[]>(initialMovies);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [sortBy, setSortBy] = useState<SortType>('rating');
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [watchHistory, setWatchHistory] = useState<string[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('home');
  const [showTMDbSetup, setShowTMDbSetup] = useState(false);
  const [showTMDbBanner, setShowTMDbBanner] = useState(true);
  const [tmdbLanguageMovies, setTmdbLanguageMovies] = useState<Map<string, Movie[]>>(new Map());

  // TMDb hook
  const {
    isConfigured: tmdbConfigured,
    isValidating,
    validationError,
    saveKey,
    removeKey,
    categories: tmdbCategories,
    trendingMovies: tmdbTrending,
    fetchByLanguage,
  } = useTMDb();

  // Load favorites, watch history and AI movies from localStorage
  useEffect(() => {
    const storedFavorites = localStorage.getItem('moviemind-favorites');
    const storedWatchHistory = localStorage.getItem('moviemind-watched');
    const storedAIMovies = localStorage.getItem('moviemind-ai-movies');

    if (storedFavorites) {
      try { setFavorites(JSON.parse(storedFavorites)); } catch {}
    }
    if (storedWatchHistory) {
      try { setWatchHistory(JSON.parse(storedWatchHistory)); } catch {}
    }
    if (storedAIMovies) {
      try {
        const aiMovies: Movie[] = JSON.parse(storedAIMovies);
        setMovies((prev) => [...prev, ...aiMovies]);
      } catch {}
    }
  }, []);

  // Fetch TMDb movies for selected language rows
  useEffect(() => {
    if (!tmdbConfigured) return;
    const langs = LANG_PRIORITY.slice(0, 6);
    langs.forEach(async (lang) => {
      try {
        const res = await fetchByLanguage(lang);
        if (res.length > 0) {
          setTmdbLanguageMovies((prev) => new Map(prev).set(lang, res));
        }
      } catch {}
    });
  }, [tmdbConfigured, fetchByLanguage]);

  // AI Hook
  const { aiLearnedMovies, isLearning, getTopGenre, getRecommendations, getTrending } =
    useMovieAI(movies, searchQuery, favorites, watchHistory);

  // AI-learned movie additions
  useEffect(() => {
    if (aiLearnedMovies.length === 0) return;
    const latestLearned = aiLearnedMovies[aiLearnedMovies.length - 1];
    const alreadyExists = movies.some(
      (m) => m.title.toLowerCase() === latestLearned.title.toLowerCase()
    );
    if (!alreadyExists) {
      const newMovie: Movie = {
        id: latestLearned.id,
        title: latestLearned.title,
        language: 'en',
        year: 2024,
        rating: 7.5,
        genres: ['Drama'],
        overview: `AI-generated entry for "${latestLearned.title}". This movie was added based on your search query.`,
        poster: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400',
        backdrop: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=1200',
        isAIGenerated: true,
      };
      setMovies((prev) => {
        const updated = [...prev, newMovie];
        const aiMovies = updated.filter((m) => m.isAIGenerated);
        localStorage.setItem('moviemind-ai-movies', JSON.stringify(aiMovies));
        return updated;
      });
    }
  }, [aiLearnedMovies, movies]);

  const toggleFavorite = useCallback((id: string) => {
    setFavorites((prev) => {
      const updated = prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id];
      localStorage.setItem('moviemind-favorites', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const toggleWatched = useCallback((id: string) => {
    setWatchHistory((prev) => {
      const updated = prev.includes(id) ? prev.filter((w) => w !== id) : [...prev, id];
      localStorage.setItem('moviemind-watched', JSON.stringify(updated));
      return updated;
    });
  }, []);

  // Filtered + sorted movies for browse/search view
  const filteredMovies = useMemo(() => {
    let result = movies;

    if (activeTab === 'favorites') result = result.filter((m) => favorites.includes(m.id));
    else if (activeTab === 'watched') result = result.filter((m) => watchHistory.includes(m.id));

    if (selectedLanguage !== 'all') result = result.filter((m) => m.language === selectedLanguage);
    if (selectedGenre !== 'All') result = result.filter((m) => m.genres.includes(selectedGenre));

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (m) =>
          m.title.toLowerCase().includes(q) ||
          m.overview.toLowerCase().includes(q) ||
          m.genres.some((g) => g.toLowerCase().includes(q)) ||
          m.director?.toLowerCase().includes(q) ||
          m.cast?.some((c) => c.toLowerCase().includes(q))
      );
    }

    if (sortBy === 'rating') result = [...result].sort((a, b) => b.rating - a.rating);
    else if (sortBy === 'newest') result = [...result].sort((a, b) => b.year - a.year);
    else if (sortBy === 'alphabetical') result = [...result].sort((a, b) => a.title.localeCompare(b.title));

    return result;
  }, [movies, activeTab, favorites, watchHistory, selectedLanguage, selectedGenre, searchQuery, sortBy]);

  const selectedLanguageInfo = LANGUAGES.find((l) => l.code === selectedLanguage) || null;
  const isSearchActive = searchQuery.trim() !== '' || selectedLanguage !== 'all' || selectedGenre !== 'All' || activeTab !== 'all';

  // Determine hero movies
  const heroMovies = useMemo(() => {
    if (tmdbTrending.length > 0) return tmdbTrending.slice(0, 8);
    return movies
      .filter((m) => m.rating >= 8.0 && m.backdrop)
      .sort(() => Math.random() - 0.5)
      .slice(0, 8);
  }, [tmdbTrending, movies]);

  // Static language rows grouped from local database
  const staticByLang = useMemo(() => groupByLanguage(movies), [movies]);

  // Combine TMDb and static for language rows
  const langRows = useMemo(() => {
    return LANG_PRIORITY.map((code) => {
      const langInfo = LANGUAGES.find((l) => l.code === code);
      if (!langInfo) return null;
      const tmdbMovies = tmdbLanguageMovies.get(code) || [];
      const staticMovies = staticByLang.get(code) || [];
      const combined = [...tmdbMovies, ...staticMovies].filter(
        (m, i, arr) => arr.findIndex((x) => x.id === m.id || x.tmdbId === m.tmdbId) === i
      );
      if (combined.length === 0) return null;
      return { code, name: langInfo.name, flag: langInfo.flag, movies: combined };
    }).filter(Boolean) as Array<{ code: string; name: string; flag: string; movies: Movie[] }>;
  }, [tmdbLanguageMovies, staticByLang]);

  // Genre rows from static data
  const genreRows = useMemo(() => {
    const genres = ['Action', 'Drama', 'Thriller', 'Comedy', 'Sci-Fi', 'Horror', 'Romance', 'Animation', 'Crime', 'Fantasy'];
    return genres.map((g) => ({
      genre: g,
      movies: movies.filter((m) => m.genres.includes(g)).sort((a, b) => b.rating - a.rating),
    })).filter((r) => r.movies.length >= 3);
  }, [movies]);

  const topRatedStatic = useMemo(
    () => [...movies].sort((a, b) => b.rating - a.rating).slice(0, 20),
    [movies]
  );

  const cardProps = { favorites, watchHistory, onToggleFavorite: toggleFavorite, onToggleWatched: toggleWatched, onMovieClick: setSelectedMovie };

  return (
    <div className="min-h-screen bg-zinc-950 text-white flex">
      <div className="flex-1 flex flex-col min-w-0">
        {/* ── Header ── */}
        <header className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40">
          <div className="px-4 md:px-6 py-3">
            <div className="flex items-center gap-3 mb-3">
              {/* Logo */}
              <div className="size-9 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center flex-none">
                <Film className="size-5" />
              </div>
              <div className="flex-none">
                <h1 className="text-xl font-black tracking-tight">MovieMind AI</h1>
              </div>

              {/* Nav */}
              <div className="flex items-center gap-1 ml-4">
                <button
                  onClick={() => { setViewMode('home'); setSearchQuery(''); setSelectedLanguage('all'); setSelectedGenre('All'); setActiveTab('all'); }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    viewMode === 'home' && !isSearchActive ? 'bg-white/10 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Home className="size-4" />
                  <span className="hidden sm:inline">Home</span>
                </button>
                <button
                  onClick={() => setViewMode('browse')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    viewMode === 'browse' ? 'bg-white/10 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <LayoutGrid className="size-4" />
                  <span className="hidden sm:inline">Browse</span>
                </button>
                <button
                  onClick={() => setActiveTab('favorites')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'favorites' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Heart className="size-4" />
                  <span className="hidden sm:inline">Favorites</span>
                  {favorites.length > 0 && (
                    <span className="px-1.5 py-0.5 bg-red-500 text-white text-xs rounded-full">{favorites.length}</span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('watched')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'watched' ? 'bg-green-600 text-white' : 'text-zinc-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Eye className="size-4" />
                  <span className="hidden sm:inline">Watched</span>
                  {watchHistory.length > 0 && (
                    <span className="px-1.5 py-0.5 bg-green-500 text-white text-xs rounded-full">{watchHistory.length}</span>
                  )}
                </button>
              </div>

              <div className="flex-1" />

              {/* TMDb Status */}
              <button
                onClick={() => setShowTMDbSetup(true)}
                className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                  tmdbConfigured
                    ? 'border-green-600/50 text-green-400 bg-green-950/30 hover:bg-green-950/50'
                    : 'border-zinc-700 text-zinc-400 hover:border-yellow-500/50 hover:text-yellow-400'
                }`}
              >
                <Tv2 className="size-3.5" />
                {tmdbConfigured ? 'TMDb Connected' : 'Connect TMDb'}
              </button>

              {/* Language Selector */}
              <div className="relative">
                <button
                  onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
                  className="flex items-center gap-2 px-3 py-2 bg-zinc-800 rounded-lg hover:bg-zinc-700 transition-colors text-sm"
                >
                  <span>{selectedLanguageInfo?.flag || '🌍'}</span>
                  <span className="hidden sm:inline">{selectedLanguageInfo?.name || 'All'}</span>
                  <ChevronDown className="size-4" />
                </button>

                {showLanguageDropdown && (
                  <div className="absolute right-0 mt-2 w-52 bg-zinc-800 border border-zinc-700 rounded-xl shadow-2xl overflow-hidden z-50 max-h-80 overflow-y-auto">
                    <button
                      onClick={() => { setSelectedLanguage('all'); setShowLanguageDropdown(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 hover:bg-zinc-700 transition-colors text-sm ${selectedLanguage === 'all' ? 'bg-zinc-700' : ''}`}
                    >
                      <span>🌍</span><span>All Languages</span>
                    </button>
                    {LANGUAGES.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => { setSelectedLanguage(lang.code); setShowLanguageDropdown(false); setViewMode('browse'); }}
                        className={`w-full flex items-center gap-3 px-4 py-2.5 hover:bg-zinc-700 transition-colors text-sm ${selectedLanguage === lang.code ? 'bg-zinc-700' : ''}`}
                      >
                        <span>{lang.flag}</span><span>{lang.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-zinc-400" />
              <input
                type="text"
                placeholder="Search movies, directors, cast..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); if (e.target.value) setViewMode('browse'); }}
                className="w-full pl-11 pr-4 py-2.5 bg-zinc-800 rounded-xl border border-zinc-700 focus:outline-none focus:border-red-600 transition-colors placeholder:text-zinc-500 text-sm"
              />
              {isLearning && (
                <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2 text-purple-400">
                  <div className="size-1.5 bg-purple-400 rounded-full animate-pulse" />
                  <span className="text-xs">AI Learning...</span>
                </div>
              )}
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                >
                  <X className="size-4" />
                </button>
              )}
            </div>
          </div>

          {/* Genre filter strip (browse mode only) */}
          {(viewMode === 'browse' || isSearchActive) && (
            <div className="px-4 md:px-6 pb-3 flex items-center gap-2 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
              {GENRES.map((genre) => (
                <button
                  key={genre}
                  onClick={() => setSelectedGenre(genre)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors flex-none ${
                    selectedGenre === genre ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                  }`}
                >
                  {genre}
                </button>
              ))}
              <div className="ml-auto flex-none">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortType)}
                  className="px-3 py-1.5 bg-zinc-800 rounded-lg border border-zinc-700 focus:outline-none text-white text-xs"
                >
                  <option value="rating">Top Rated</option>
                  <option value="newest">Newest</option>
                  <option value="alphabetical">A-Z</option>
                </select>
              </div>
            </div>
          )}
        </header>

        {/* ── TMDb Setup Banner ── */}
        {!tmdbConfigured && showTMDbBanner && viewMode === 'home' && (
          <div className="px-6 py-3 bg-gradient-to-r from-yellow-950/50 to-zinc-900/50 border-b border-yellow-800/30 flex items-center gap-3">
            <span className="text-yellow-400 text-sm">🎬 Connect TMDb API for 500,000+ real movies with posters, trailers & live data.</span>
            <button
              onClick={() => setShowTMDbSetup(true)}
              className="px-3 py-1 bg-yellow-600 hover:bg-yellow-500 text-white text-xs rounded-lg transition-colors font-semibold flex-none"
            >
              Connect Free
            </button>
            <button onClick={() => setShowTMDbBanner(false)} className="ml-auto text-zinc-500 hover:text-white">
              <X className="size-4" />
            </button>
          </div>
        )}

        {/* ── TMDb Setup Modal ── */}
        {showTMDbSetup && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" onClick={() => setShowTMDbSetup(false)}>
            <div onClick={(e) => e.stopPropagation()}>
              {tmdbConfigured ? (
                <div className="bg-zinc-900 rounded-2xl border border-zinc-800 p-8 max-w-md w-full text-center">
                  <div className="size-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                    <Tv2 className="size-8 text-green-400" />
                  </div>
                  <h2 className="text-xl font-bold text-white mb-2">TMDb Connected</h2>
                  <p className="text-zinc-400 text-sm mb-6">Your API key is active and movies are loading.</p>
                  <button
                    onClick={() => { removeKey(); setShowTMDbSetup(false); }}
                    className="px-6 py-2.5 bg-red-900/50 hover:bg-red-900/70 text-red-300 rounded-xl transition-colors text-sm"
                  >
                    Disconnect API Key
                  </button>
                  <button onClick={() => setShowTMDbSetup(false)} className="block mx-auto mt-3 text-zinc-500 text-sm hover:text-zinc-300">
                    Close
                  </button>
                </div>
              ) : (
                <TMDbSetup
                  onSave={saveKey}
                  onDismiss={() => setShowTMDbSetup(false)}
                  isValidating={isValidating}
                  validationError={validationError}
                />
              )}
            </div>
          </div>
        )}

        {/* ── Main Content ── */}
        {isSearchActive || viewMode === 'browse' ? (
          /* ── Browse / Search Grid View ── */
          <div className="flex-1 overflow-y-auto p-4 md:p-6">
            {isSearchActive && (
              <div className="mb-4 flex items-center justify-between">
                <p className="text-zinc-400 text-sm">
                  {filteredMovies.length} movies found
                  {searchQuery && <span className="text-white"> for "{searchQuery}"</span>}
                </p>
                {isSearchActive && (
                  <button
                    onClick={() => { setSearchQuery(''); setSelectedLanguage('all'); setSelectedGenre('All'); setActiveTab('all'); setViewMode('home'); }}
                    className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1"
                  >
                    <X className="size-4" /> Clear filters
                  </button>
                )}
              </div>
            )}

            {filteredMovies.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                {filteredMovies.map((movie) => (
                  <MovieCard
                    key={movie.id}
                    movie={movie}
                    isFavorite={favorites.includes(movie.id)}
                    isWatched={watchHistory.includes(movie.id)}
                    onToggleFavorite={toggleFavorite}
                    onToggleWatched={toggleWatched}
                    onClick={setSelectedMovie}
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <div className="size-20 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
                  <Film className="size-10 text-zinc-600" />
                </div>
                <h3 className="text-lg font-semibold text-zinc-400 mb-2">No movies found</h3>
                <p className="text-zinc-500 text-sm">
                  {searchQuery ? 'Try a different term or ask the AI chatbot!' : 'Try adjusting your filters'}
                </p>
              </div>
            )}
          </div>
        ) : (
          /* ── Home / Netflix View ── */
          <div className="flex-1 overflow-y-auto">
            {/* Hero Banner */}
            {heroMovies.length > 0 && (
              <HeroBanner
                movies={heroMovies}
                onMovieClick={setSelectedMovie}
                onToggleFavorite={toggleFavorite}
                onToggleWatched={toggleWatched}
                favorites={favorites}
                watchHistory={watchHistory}
              />
            )}

            <div className="py-6">
              {/* TMDb Dynamic Categories */}
              {tmdbConfigured && tmdbCategories.map((cat) => (
                <CategoryRow
                  key={cat.id}
                  title={cat.title}
                  movies={cat.movies}
                  loading={cat.loading}
                  {...cardProps}
                />
              ))}

              {/* Trending / Top Rated from local DB */}
              {!tmdbConfigured && (
                <CategoryRow
                  title="🔥 Trending Now"
                  movies={topRatedStatic.slice(0, 15)}
                  {...cardProps}
                />
              )}

              <CategoryRow
                title="⭐ Top Rated"
                movies={topRatedStatic}
                {...cardProps}
              />

              {/* Language Rows */}
              {langRows.map(({ code, name, flag, movies: lMovies }) => (
                <CategoryRow
                  key={code}
                  title={`${flag} ${name} Cinema`}
                  movies={lMovies}
                  {...cardProps}
                />
              ))}

              {/* Genre Rows */}
              {genreRows.map(({ genre, movies: gMovies }) => (
                <CategoryRow
                  key={genre}
                  title={`${genreEmoji(genre)} ${genre}`}
                  movies={gMovies}
                  {...cardProps}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* AI Sidebar */}
      <div className="hidden xl:block">
        <AIRecommendations
          topGenre={getTopGenre()}
          recommendations={getRecommendations(5)}
          trending={getTrending(5)}
          aiLearnedMovies={aiLearnedMovies}
          watchedCount={watchHistory.length}
          onMovieClick={setSelectedMovie}
        />
      </div>

      {/* AI Chatbot */}
      <AIChatbot
        movies={movies}
        favorites={favorites}
        watchHistory={watchHistory}
        onMovieClick={setSelectedMovie}
      />

      {/* Movie Modal */}
      {selectedMovie && (
        <MovieModal
          movie={selectedMovie}
          isFavorite={favorites.includes(selectedMovie.id)}
          isWatched={watchHistory.includes(selectedMovie.id)}
          onClose={() => setSelectedMovie(null)}
          onToggleFavorite={toggleFavorite}
          onToggleWatched={toggleWatched}
        />
      )}

      {/* Dropdown backdrop */}
      {showLanguageDropdown && (
        <div className="fixed inset-0 z-30" onClick={() => setShowLanguageDropdown(false)} />
      )}
    </div>
  );
}

function genreEmoji(genre: string): string {
  const map: Record<string, string> = {
    Action: '💥', Drama: '🎭', Thriller: '🔪', Comedy: '😂',
    'Sci-Fi': '🚀', Horror: '👻', Romance: '❤️', Animation: '🎨',
    Crime: '🕵️', Fantasy: '🧙', Adventure: '🌍', Biography: '📖',
    War: '⚔️', Mystery: '🔍',
  };
  return map[genre] || '🎬';
}
