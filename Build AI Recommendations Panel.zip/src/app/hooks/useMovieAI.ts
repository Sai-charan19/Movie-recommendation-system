import { useState, useEffect } from 'react';
import { Movie } from '../data/movies';

interface AILearnedMovie {
  id: string;
  title: string;
  timestamp: number;
}

export function useMovieAI(
  movies: Movie[],
  searchQuery: string,
  favorites: string[],
  watchHistory: string[]
) {
  const [aiLearnedMovies, setAiLearnedMovies] = useState<AILearnedMovie[]>([]);
  const [isLearning, setIsLearning] = useState(false);

  // Load AI learned movies from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('moviemind-ai-learned');
    if (stored) {
      try {
        setAiLearnedMovies(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse AI learned movies', e);
      }
    }
  }, []);

  // Smart search learning: detect when search yields no results
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 3) return;

    const matchedMovies = movies.filter(
      (m) =>
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.overview.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.genres.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    // If no matches and query is substantial, trigger AI learning
    if (matchedMovies.length === 0 && searchQuery.length >= 3) {
      setIsLearning(true);

      // Simulate AI thinking time
      const timer = setTimeout(() => {
        // Check if this movie was already learned
        const alreadyLearned = aiLearnedMovies.some(
          (lm) => lm.title.toLowerCase() === searchQuery.toLowerCase()
        );

        if (!alreadyLearned) {
          const newLearned: AILearnedMovie = {
            id: `ai-${Date.now()}`,
            title: searchQuery,
            timestamp: Date.now(),
          };

          const updated = [...aiLearnedMovies, newLearned];
          setAiLearnedMovies(updated);
          localStorage.setItem('moviemind-ai-learned', JSON.stringify(updated));
        }

        setIsLearning(false);
      }, 1800);

      return () => clearTimeout(timer);
    } else {
      setIsLearning(false);
    }
  }, [searchQuery, movies, aiLearnedMovies]);

  // Get top genre from favorites
  const getTopGenre = (): string => {
    const favoriteMovies = movies.filter((m) => favorites.includes(m.id));
    const genreCounts: Record<string, number> = {};

    favoriteMovies.forEach((movie) => {
      movie.genres.forEach((genre) => {
        genreCounts[genre] = (genreCounts[genre] || 0) + 1;
      });
    });

    const sorted = Object.entries(genreCounts).sort((a, b) => b[1] - a[1]);
    return sorted.length > 0 ? sorted[0][0] : 'Action';
  };

  // Get AI recommendations
  const getRecommendations = (limit = 5): Movie[] => {
    const topGenre = getTopGenre();
    const unwatched = movies.filter((m) => !watchHistory.includes(m.id));
    const genreMatches = unwatched
      .filter((m) => m.genres.includes(topGenre))
      .sort((a, b) => b.rating - a.rating);

    return genreMatches.slice(0, limit);
  };

  // Get trending (high-rated recent movies)
  const getTrending = (limit = 5): Movie[] => {
    return movies
      .filter((m) => m.year >= 2015)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  };

  return {
    aiLearnedMovies,
    isLearning,
    getTopGenre,
    getRecommendations,
    getTrending,
  };
}
