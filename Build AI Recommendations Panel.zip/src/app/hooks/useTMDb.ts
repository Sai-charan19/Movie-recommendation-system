import { useState, useEffect, useCallback, useRef } from 'react';
import { Movie } from '../data/movies';
import { TMDbService, getTMDbService, setTMDbKey, clearTMDbKey, getTMDbKey } from '../services/tmdbService';

interface TMDbCategory {
  id: string;
  title: string;
  movies: Movie[];
  loading: boolean;
}

interface UseTMDbReturn {
  apiKey: string;
  isConfigured: boolean;
  isValidating: boolean;
  validationError: string | null;
  saveKey: (key: string) => Promise<boolean>;
  removeKey: () => void;
  categories: TMDbCategory[];
  trendingMovies: Movie[];
  fetchByLanguage: (lang: string) => Promise<Movie[]>;
  searchTMDb: (query: string) => Promise<Movie[]>;
  enrichMovie: (movie: Movie) => Promise<Movie>;
}

const CATEGORY_CONFIGS = [
  { id: 'trending', title: 'Trending This Week' },
  { id: 'now_playing', title: 'Now Playing' },
  { id: 'top_rated', title: 'Top Rated Worldwide' },
  { id: 'action', title: 'Action & Adventure' },
  { id: 'horror', title: 'Horror & Thriller' },
  { id: 'comedy', title: 'Comedy' },
  { id: 'animation', title: 'Animation' },
];

export function useTMDb(): UseTMDbReturn {
  const [apiKey, setApiKey] = useState(getTMDbKey);
  const [isValidating, setIsValidating] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [categories, setCategories] = useState<TMDbCategory[]>([]);
  const [trendingMovies, setTrendingMovies] = useState<Movie[]>([]);
  const serviceRef = useRef<TMDbService | null>(getTMDbService());
  const fetchedRef = useRef(false);

  const fetchCategories = useCallback(async (svc: TMDbService) => {
    if (fetchedRef.current) return;
    fetchedRef.current = true;

    // Initialize empty categories
    setCategories(CATEGORY_CONFIGS.map((c) => ({ ...c, movies: [], loading: true })));

    const update = (id: string, movies: Movie[]) => {
      setCategories((prev) =>
        prev.map((c) => (c.id === id ? { ...c, movies, loading: false } : c))
      );
    };

    // Fetch trending first for hero banner
    try {
      const trending = await svc.fetchTrending('week');
      setTrendingMovies(trending);
      update('trending', trending);
    } catch { update('trending', []); }

    // Parallel fetch for the rest
    const fetches: Array<[string, Promise<Movie[]>]> = [
      ['now_playing', svc.fetchNowPlaying()],
      ['top_rated', svc.fetchTopRated()],
      ['action', svc.fetchByGenre(28)],
      ['horror', svc.fetchByGenre(27)],
      ['comedy', svc.fetchByGenre(35)],
      ['animation', svc.fetchByGenre(16)],
    ];

    for (const [id, promise] of fetches) {
      promise
        .then((movies) => update(id, movies))
        .catch(() => update(id, []));
    }
  }, []);

  useEffect(() => {
    const svc = getTMDbService();
    serviceRef.current = svc;
    if (svc && apiKey) {
      fetchCategories(svc);
    }
  }, [apiKey, fetchCategories]);

  const saveKey = useCallback(async (key: string): Promise<boolean> => {
    setIsValidating(true);
    setValidationError(null);
    try {
      const svc = setTMDbKey(key);
      const valid = await svc.validateKey();
      if (valid) {
        serviceRef.current = svc;
        setApiKey(key);
        fetchedRef.current = false;
        fetchCategories(svc);
        return true;
      } else {
        clearTMDbKey();
        setValidationError('Invalid API key. Please check and try again.');
        return false;
      }
    } catch {
      setValidationError('Network error. Please check your connection.');
      return false;
    } finally {
      setIsValidating(false);
    }
  }, [fetchCategories]);

  const removeKey = useCallback(() => {
    clearTMDbKey();
    setApiKey('');
    setCategories([]);
    setTrendingMovies([]);
    fetchedRef.current = false;
    serviceRef.current = null;
  }, []);

  const fetchByLanguage = useCallback(async (lang: string): Promise<Movie[]> => {
    const svc = serviceRef.current;
    if (!svc) return [];
    return svc.fetchByLanguage(lang);
  }, []);

  const searchTMDb = useCallback(async (query: string): Promise<Movie[]> => {
    const svc = serviceRef.current;
    if (!svc || !query.trim()) return [];
    return svc.searchMovies(query);
  }, []);

  const enrichMovie = useCallback(async (movie: Movie): Promise<Movie> => {
    const svc = serviceRef.current;
    if (!svc) return movie;
    return svc.enrichMovie(movie);
  }, []);

  return {
    apiKey,
    isConfigured: !!apiKey,
    isValidating,
    validationError,
    saveKey,
    removeKey,
    categories,
    trendingMovies,
    fetchByLanguage,
    searchTMDb,
    enrichMovie,
  };
}
